<?php
include('../connect.php');
include('../addstudent.php');
include('../session_admin.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Federal University Of Technology Owerri</title>

	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" media="print" href="print.css" />
	<!-- Custom Theme Style -->
	<link href="../build/css/custom.min.css" rel="stylesheet">
	<!-- icon -->
	<link rel="icon" href="../images/green-chmsc-official-logo.png" >
</head>

<body class="nav-md">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col menu_fixed">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="#" class="site_title"> <span>FUTO</span></a>
					</div>

					<div class="clearfix"></div>

					<!-- menu profile quick info -->
					<div class="profile">
						<div class="profile_pic">
							<img src="..\img\sample.png" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
							<span>Welcome,</span>
							<h2><?php echo "$name"; ?></h2>
						</div>
					</div>
					<!-- /menu profile quick info -->

					<br />

					<!-- sidebar menu -->
					<!-- /sidebar menu -->
				</div>
			</div>

			<!-- top navigation -->
			<div class="top_nav">
				<div class="nav_menu">
					<nav>
						<div class="nav toggle">
							<a id="menu_toggle"><i class="fa fa-bars"></i></a>
						</div>

						<ul class="nav navbar-nav navbar-right">
							<li class="">
								<a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<img src="../images/img.jpg" alt="profile Image">Admin
									<span class=" fa fa-angle-down"></span>
								</a>
								<ul class="dropdown-menu dropdown-usermenu pull-right">
									
									<li><a href="javascript:;" data-toggle="modal" data-target="#change_pass">Change password</a></li>
									<li><a href="..\index.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
								</ul>
							</li>
							<li role="presentation" class="dropdown">
							</li>
						</ul>
					</nav>
				</div>
			</div>
			<!-- /top navigation -->

			<!-- page content -->
			<div class="right_col" role="main">
				<div class="">
					<div class="page-title">
						<div class="title_left">
							<h3><a href="admin1.php"> <i class="fa fa-arrow-left"></i> Back</a></h3>
						</div>
						<div class="title_right">				

						</div>
					</div>

					<div class="clearfix"></div>
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="x_panel">
							<div class="x_title">
								<h2></h2>
								<div class="row">
									<div class="col-md-12">
										<ul class="nav nav-pills">
											<li class="active"><a data-toggle="pill" href="#pds">Personal Data Sheet</a></li>
											<li><a data-toggle="pill" href="#clearance">Clearance Status</a></li>
										</ul>
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="x_content col-md-12" >
								<form action="../update_stud_pd.php" method="post" class="form-horizontal form-label-left">
									<div class="container-fluid" style="border: 2px solid">
										<div class="tab-content">
											<?php
											$a = $_POST['haydi'];
											$sql = "SELECT * FROM stud_pi 
											NATURAL JOIN stud_pi_snk 
											NATURAL JOIN stud_program_details
											
											NATURAL JOIN clearance WHERE id = $a ";
											$query = $conn->prepare($sql);
											$query->execute();
											$fetch = $query->fetchAll();

											foreach ($fetch as $key => $value) { ?>
											<!-- Personal info tab -->
											<div id="pds" class="tab-pane fade in active">
												<div class="row">
													<div class="col-md-3">
														<small>Clearance Form (Revised 2019)</small>
													</div>
													<div class="row">
														<div class="col-md-12">
															<center><h2><strong>PERSONAL DATA SHEET</strong></h2></center>
														</div>
													</div>
													<div class="row">
														<div class="col-md-6">
														</div>
														<div class="col-md-4 pull-right">
															<strong>1.Clearance ID. ______________________________</strong>
														</div>
													</div>
													<table class="table table-bordered" style="margin-bottom: 0%;">
														<thead>
															<tr>
																<td colspan="4"><h5><strong>I. Personal Information</strong></h5></td>
															</tr>
														</thead>
														<tbody>
															<tr>
																<td width="15%">2. Surname</td>
																<td colspan="4"><?php echo $value['surname'];?></td>
															</tr>
															<tr>
																<td>First Name</td>
																<td colspan="4"><?php echo $value['firstname'];?></td>
															</tr>
															<tr>
																<td>Middle Name</td>
																<td width="30%"><?php echo $value['middlename'];?></td>
																<td width="17%">3. Name Extension</td>
																<td><?php echo $value['name_extension'];?></td>
															</tr>
															<tr>
																<td>4. Date Of Birth</td>
																<td><?php echo $value['dob'];?></td>
																<td rowspan="2">16. Place Of Birth</td>
																<td rowspan="2"><?php echo $value['place_of_birth']; ?></td>
																<td rowspan="2">16. State Of Origin</td>
																<td rowspan="2"><?php echo $value['state_of_origin']; ?></td>
															</tr>
															<tr>
																<td>5. LGA</td>
																<td><?php echo $value['LGA']; ?></td>
															</tr>
															<tr>
																<td>6. Sex</td>
																<td><?php echo $value['sex']; ?></td>
																<td><div class="pull-right">Home Town</div></td>
																<td><?php echo $value['home_town']; ?></td>
															</tr>
															
															<tr>
																<td>8. Permanent Address</td>
																<td><?php echo $value['permanent_address']; ?></td>
																<td rowspan="2">18. Blood Group</td>
																<td rowspan="2"><?php echo $value['blood_group']; ?></td>
															</tr>
															<tr>
																<td>9. Tell</td>
																<td><?php echo $value['tel']; ?> </td>
															</tr>
															<tr>
																<td>10. Genotype</td>
																<td><?php echo $value['genotype']; ?> </td>
																<td><div class="pull-right">Religion</div></td>
																<td><?php echo $value['religion']; ?></td>
															</tr>
															<tr>
																<td>11. Email</td>
																<td>Type <?php echo $value['email']; ?></td>
																
															</tr>
															
															
															
														</tbody>
													</table>
													<table class="table table-bordered" style="margin-bottom: 0%;">
														<thead>
															<tr>
																<td colspan="4"><h5><strong>II. Sponsor Information</strong></h5></td>
															</tr>
														</thead>
														<tbody>
															<tr>
																<td width="15%">24. Sponsor Name</td>
																<td width="30%"><?php echo $value['sponsor_name']; ?></td>
																
															</tr>
															
															
															<tr>
																<td width="15%">Sponsor Number</td>
																<td width="30%"><?php echo $value['sponsor_num']; ?></td>
																<td></td>
																<td></td>
															</tr>
															<tr>
																<td width="15%">Sponsor Email</td>
																<td width="30%"><?php echo $value['sponsor_email']; ?></td>
																<td></td>
																<td></td>
															</tr>
															<tr>
																<td width="15%">Relationship</td>
																<td width="30%"><?php echo $value['relationship']; ?></td>
																<td></td>
																<td></td>
															</tr>
															<tr>
																<td width="15%">Sponsor's Next Of Kin.</td>
																<td width="30%"><?php echo $value['spon_next_of_kin']; ?></td>
																<td></td>
																<td></td>
															</tr>
															<tr>
																<td width="15%">26. Next Of Kin Address</td>
																<td width="30%"><?php echo $value['spon_next_of_kin_address']; ?></td>
																<td></td>
																<td></td>
															</tr>
															<tr>
																<td width="15%"><div class="pull-right">Mobile Of Next Of Kin</div></td>
																<td width="30%"><?php echo $value['spon_next_of_kin_mobile']; ?></td>
																<td></td>
																<td></td>
															</tr>
															<tr>
																<td width="15%"><div class="pull-right">Next Of Kin Email</div></td>
																<td width="30%"><?php echo $value['spon_next_of_kin_email']; ?></td>
																<td></td>
																<td></td>
															</tr>
															
															
															
														</tbody>
													</table>
													
													<table class="table table-bordered" style="margin-bottom: 0%;">
														<thead>
															<tr>
																<td colspan="12"><h5><strong>III. Program Details</strong></h5></td>
															</tr>
														</thead>
														<thead>
															<tr>
																
															    <td rowspan="1">Student Option</td>
																<td rowspan="1">Student Type</td>
																<td rowspan="1">Programme</td>
																<td colspan="1">Jamb No </td>
																<td rowspan="1">Mode Of Entry</td>
																<td rowspan="1">Student Mode</td>
																<td rowspan="1">Entry Year</td>
																<td rowspan="1">Year Of Graduation</td>
																<td rowspan="1">Year Of Study</td>
																<td rowspan="1">Entry Level</td>
															</tr>
															
														</thead>
														<tbody>
															<tr>
																
															    <td><?php echo $value['option_std']; ?></td>
																<td><?php echo $value['student_type']; ?></td>
																<td><?php echo $value['programme']; ?></td>
																<td><?php echo $value['jamb_no']; ?></td>
																<td><?php echo $value['mode_of_entry']; ?></td>
																<td><?php echo $value['student_mode']; ?></td>
																<td><?php echo $value['entry_year']; ?></td>
																<td><?php echo $value['year_of_graduation']; ?></td>
																<td><?php echo $value['year_of_study']; ?></td>
																<td><?php echo $value['entry_level']; ?></td>
															</tr>
														</tbody>
													</table>
													
														
													
														
													
														
													
																</table>
															</tr>									
														</tbody>
													</table>
												</div>
											</div>
											<!--/ Personal info tab -->
											
											<div id="clearance" class="tab-pane fade">
												<div class="row">
													<div class="col-md-12">
														<?php	
														$sql = "SELECT * FROM student WHERE id = $a ";
														$query = $conn->prepare($sql);
														$query->execute(array($a));
														$row = $query->fetch();
														$name = $row['stud_Fname']. " " . $row['stud_Mname']. " " . $row['stud_Lname'];
														$designation = $row['department']; 
														$pic = $row['stud_picture'];
														?>
														<center>
															Federal Republic Of Nigeria<br />
															<strong>Federal University Of Technology</strong><br />
															Owerri, Imo State
															<br />
															<br />
															<strong>Departmental Clearance</strong>
															<br />
															<small>(Purpose: Service(NYSC), Scholoarship, Further Your Education)</small>
														</center>
													</div>
													<div class="row">
														<div class="col-md-3 pull-right">
															<center>______________
																<br />
																Date</center>
															</div>
														</div>
														<div class="row">
															<div class="col-md-3">
																<strong>The HOD</strong><br />
																FUTO <br />
																IMT<br /><br />
																<u><?php echo $name ?></u>:<br />
															</div>
														</div>
														<div class="row">
															<div class="col-md-12">
																<p>
																	I have the honor to inform your good Office that I have satisfactoryily accounted for all money and property accountabilities and that all reports were complied with on dates shown below :
																</p>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-md-12">
															<center>
																<label>Until
																	<input type="text" class="col-md-1 pull-right" name="other_civil_status" style="width: 70%;
																	border-top: none; border-left: none; border-right:none; border-bottom: 1px solid; margin-left: -30px;">
																</label>
																<label>, my mailing address will be
																	<input type="text" class="col-md-1 pull-right" name="other_civil_status" style="width: 51%;border-top: none;border-left: none;border-right: none;border-bottom: 1px solid;">
																</label>
															</center>
														</div>
														<div class="col-md-3 pull-right">
															<div class="pull-right">
																<p>Very truly yours,</p>
																<u><?php echo $name ?></u><br />
																<b>(Print name before signing)</b>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-md-3 pull-right">
															<div class="pull-right">
																<u><?php echo $designation ?></u><br />
																<b>(Designation)</b>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-md-12">
															<div class="row">
																<br />
																<br />
																<br />
																<center><h2>Certification</h2>
																	<p>WE HEREBY CERTIFY THAT <?php echo $name; ?> is cleared of all money, property and other accountabilities as of the date indicated.</p>
																</center>
															</div>
															<div class="row" style="border:1px solid;">
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_bursaryUnit_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Bursary Untit</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_projectSupervisor_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Project Supervisor</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_classAdviser_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Class Adviser</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_departmentalAdmin_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Departmental Admin</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_studentAffairs_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Student Affairs</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_librarian_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Library</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_registrar_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Registrar</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_examsAndRecords_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Exams And Records</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_dean_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Dean</small>
																		</p>
																	</center>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_HOD_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>HOD</small>
																		</p>
																	</center>
																</div>
																
																
																<div class="col-md-4">
																	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
																</div>
																<div class="col-md-4">
																	<center>
																		<?php 
																		if ($value['is_dean_approval'] == 0){
																			echo '';
																		}else{
																			echo '<i class="glyphicon glyphicon-ok"></i>';
																		}
																		?>
																		<br />
																		<p>________________________<br />
																			<small>Dean of Faculty</small>
																		</p>
																	</center>
																</div>
																
															</div>
															<div class="row">
																<h4 style="margin-left:300px">APPROVED:</h4>
																<center>
																	<?php 
																	if ($value['is_HOD_approval'] == 0){
																		echo '';
																	}else{
																		echo '<i class="glyphicon glyphicon-ok"></i>';
																	}
																	?>
																	<br />
																	<p>________________________<br />
																		<small>Senate</small>
																	</p>
																</center>
															</div>
														</div>
													</div>
												</div>
											</div>
											<!--/ Family background tab-->
										</div>
										<?php } ?>
									</div>
								</form>
								<div class="pull-right">
									<button onclick="window.print()" id="btnPrint" class="btn btn-primary btn-m " >
										Print Report
									</button>
								</div>
							</div>	<!-- /x content -->
						</div>		
					</div>
				</div>
			</div>
			<!-- /page content -->

			<!-- footer content -->
			<footer>
				<div class="pull-right">
					by:IMT Group10
				</div>
				<div class="clearfix"></div>
			</footer>
			<!-- /footer content -->
		</div>
	</div>

	<!-- jQuery -->
	<script src="../vendors/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
	<!-- FastClick -->
	<script src="../vendors/fastclick/lib/fastclick.js"></script>
	<!-- NProgress -->
	<script src="../vendors/nprogress/nprogress.js"></script>
	<!-- Custom Theme Scripts -->
	<script src="../build/js/custom.min.js"></script>
	<script src="../build/js/md5.js"></script>

	<!-- Datatables -->
	<script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
	<script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
	<script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
	<script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
	<script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
	<script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
	<script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
	<script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
	<script src="../vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
	<script src="../vendors/jszip/dist/jszip.min.js"></script>
	<script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
	<script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

	<script type="text/javascript">
		jQuery(function(){
			$('form[action="save_deadline"]').on('submit', function(e){
				e.preventDefault();

				var da = $('input[name="deadline"]').val();

				$.ajax({
					type: 'POST',
					url: 'set_deadline.php',
					data: {d_date: da}
				})
				.done(function(data){
					$('.save_dl').text('Deadline has been set');
					setTimeout(function(){
						location.reload();
					}, 3000);
				});
			});

			$('.reset_dl').on('click', function(e){
				e.preventDefault();

				$.ajax({
					type: 'POST',
					url: 'reset_dl.php'
				})
				.done(function(data){
					$('.save_dl').text('Deadline has been reset');
					setTimeout(function(){
						location.reload();
					}, 3000);
				});
			});

			$('form[name="fchange_p"]').on('submit', function(e){
				e.preventDefault();

				var sess_pass = '<?php echo $a_sess_pass; ?>';
				var sess_id = '<?php echo $a_sess_id; ?>';

				var a = $('[name="old_pass1"]').val();
				var b = $('[name="new_pass1"]').val();
				var c = $('[name="conf_pass1"]').val();

				if (md5(a) !== sess_pass){
					$('.edit_pass1').text('Please enter your current password');
					$('[name="old_pass1"]').val('').focus();
				}else{
					if (b === '' && c !== ''){
						$('.edit_pass1').text('Please enter your new password');
					}else if (b !== '' && c === ''){
						$('.edit_pass1').text('Please confirm your new password');
					}else if (b === '' && c === ''){
						$('.edit_pass1').text('Please fill out the fields');
					}else if (b !== c){
						$('.edit_pass1').text('Passwords do not match');
					}else{
						$.ajax({
							type: 'POST',
							url: 'edit_pass.php',
							data: {
								session_id: sess_id,
								password: b
							}
						})
						.done(function(data){
							$('form[name="change_p"] input[type="password"]').val('');
							if (data == 1){
								$('.edit_pass1').text('Password successfully updated');
							}else{
								$('.edit_pass1').text('An error occured. Try again');
							}

							setTimeout(function(){
								location.reload();
							}, 1000 * 3);
						});	
					}
				}
			});
		});
	</script>
	<!-- Datatables -->
	<script>
		$(document).ready(function() {
			var handleDataTableButtons = function() {
				if ($("#datatable-buttons").length) {
					$("#datatable-buttons").DataTable({
						dom: "Bfrtip",
						buttons: [
						{
							extend: "copy",
							className: "btn-sm"
						},
						{
							extend: "csv",
							className: "btn-sm"
						},
						{
							extend: "excel",
							className: "btn-sm"
						},
						{
							extend: "pdf",
							className: "btn-sm"
						},
						{
							extend: "print",
							className: "btn-sm"
						},
						],
						responsive: true
					});
				}
			};

			TableManageButtons = function() {
				"use strict";
				return {
					init: function() {
						handleDataTableButtons();
					}
				};
			}();

			$('#datatable').dataTable();

			$('#datatable-keytable').DataTable({
				keys: true
			});

			$('#datatable-responsive').DataTable();

			$('#datatable-scroller').DataTable({
				ajax: "js/datatables/json/scroller-demo.json",
				deferRender: true,
				scrollY: 380,
				scrollCollapse: true,
				scroller: true
			});

			$('#datatable-fixed-header').DataTable({
				fixedHeader: true
			});

			var $datatable = $('#datatable-checkbox');

			$datatable.dataTable({
				'order': [[ 1, 'asc' ]],
				'columnDefs': [
				{ orderable: false, targets: [0] }
				]
			});
			$datatable.on('draw.dt', function() {
				$('input').iCheck({
					checkboxClass: 'icheckbox_flat-green'
				});
			});

			TableManageButtons.init();
		});
	</script>
	<script>
		function myFunction() {
			window.print();
		}
	</script>
	<!-- /Datatables -->
</body>
</html>
