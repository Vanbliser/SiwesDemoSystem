<div class="modal fade" id="edit<?php echo $value ['id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Edit <?php echo $value['stud_Fname']; ?> Profile</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<form action="../edit_student1.php" method="POST">
						<div class="Id">
							<input value = "<?php echo $value['stud_id'];?>" type="hidden" class="form-control" name= "studId" placeholder="Reg No" required>
							<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" required>
						</div>
						<div class="firstname">
							<label>	First Name*</label>
							<input value = "<?php echo $value['stud_Fname'];?>" class="form-control" name= "firstname" placeholder="First Name" required>
						</div>
						<div class="middlename">
							<label>Middle Name</label>
							<input value = "<?php echo $value['stud_Mname'];?>" class="form-control" name= "middlename" placeholder="Middle Name" >
						</div>
						<div class="lastname">
							<label>Last Name*</label>
							<input value = "<?php echo $value['stud_Lname'];?>" class="form-control" name= "lastname" placeholder="Last Name" required>
						</div>
						<div class="contactnumber">
							<label>Contact Number</label>
							<input value = "<?php echo $value['contact_num'];?>" type="number" class="form-control" name= "contact_num" placeholder="Contact Number">
						</div>
						<div class="email">
							<label>Email</label>
							<input value = "<?php echo $value['email'];?>" class="form-control" name= "email" placeholder="Email">
						</div>
						<div class="col-md-3">
						<label>Course</label>
						<select name="course" class="form-control">
							<option>IMT</option>
							<option>IFT</option>
							<option>CSC</option>
							<option>PMT</option>
							<option>MMT</option>
							<option>EEE</option>
						</select>
					</div>
					<div class="col-md-3">
					<label>Department</label>
					<select name="department" class="form-control">
						<option>IMT</option>
						<option>IFT</option>
						<option>CSC</option>
						<option>PMT</option>
						<option>MMT</option>
						<option>EEE</option>
					</select>
				</div>
				<div class="password">
							<label>Password</label>
							<input class="form-control" name= "password" placeholder="Password">
						</div>
						<div class="col-md-3">
						<label>Campus</label>
						<select name="campus" class="form-control">
							<option>SMAT</option>
							<option>SCIT</option>
							<option>SEET</option>
							<option>SOHT</option>
						</select>
					</div>
					</div>
				</div>
				<div class="col-md-3">
				<label>Course Program</label>
				<select name="course_program" class="form-control">
					<option>B>Tech</option>
					<option>BSc</option>
					<option>MSc</option>
					<option>PhD</option>
				
				</select>
			</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
			<button type="submit" name="add" class="btn btn-primary">Save</button>
		</div>
			</form>	
		</div>
	</div>
</div>