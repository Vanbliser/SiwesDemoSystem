<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
	<div class="menu_section">
		<h3>General</h3>
		<ul class="nav side-menu">
			<li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
				<ul class="nav child_menu">
					<li><a href="student.php">Clearance Status</a></li>
					<li><a href="stud_pd.php">My Personal Data Sheet</a></li>
					<li><a href="edit_picture.php">Edit Profile Picture</a></li>
				</ul>
			</li>
			<li><a><i class="fa fa-edit"></i> Designee's <span class="fa fa-chevron-down"></span></a>
				<ul class="nav child_menu">
					<li><a href="bursaryUnit.php">Bursar</a></li>
					<li><a href="projectSupervisor.php">Project Supervisor</a></li>
					<li><a href="classAdviser.php">Class Adviser </a></li>
					<li><a href="departmentalAdmin.php">Departmental Admin</a></li>
					<li><a href="studentAffairs.php">Student Affairs</a></li>
					<li><a href="librarian.php"> Librarian</a></li>
					<li><a href="registrar.php">Registrar</a></li>
					<li><a href="examsAndRecords.php">Exams And Records</a></li>
					<li><a href="dean.php">Dean of the College</a></li>
					<li><a href="HOD.php">HOD</a></li>
					
				</ul>
			</li>
		</ul>
	</div>
</div> 