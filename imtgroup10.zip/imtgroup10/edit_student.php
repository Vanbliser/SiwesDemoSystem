<?php 
include 'connect.php';
$studId = $_POST['studId'];
$firstname = $_POST['firstname'];
$middlename = $_POST['middlename'];
$lastname = $_POST['lastname'];
$contactnumber = $_POST['contact_num'];
$email = $_POST['email'];
$course = $_POST['course'];
$department = $_POST['department'];

$campus = $_POST['campus'];
$courseProgram = $_POST['course_program'];
$id = $_POST['id'];

$query = $conn->prepare("UPDATE student SET stud_id = ?, stud_Fname = ?, stud_Mname = ?, stud_Lname = ?, contact_num = ?, email = ?, course = ?, department = ?, campus = ?, course_program = ? WHERE id = ?"); 	
$query->execute(array($studId,$firstname,$middlename,$lastname,$contactnumber,$email,$course,$department,$campus,$courseProgram,$id));
header('location:assets/admin1.php');
?>