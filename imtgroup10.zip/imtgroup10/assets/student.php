<?php
include('../session.php');
include('../connect.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Federal University Of Technology Owerri </title>

	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- jQuery custom content scroller -->
	<link href="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>

	<!-- Custom Theme Style -->
	<link href="../build/css/custom.min.css" rel="stylesheet">
	<!-- icon -->
	<link rel="icon" href="../images/green-chmsc-official-logo.png" >
</head>

<body class="nav-md">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col menu_fixed">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="#" class="site_title"> <span>FUTO</span></a>
					</div>

					<div class="clearfix"></div>

					<!-- menu profile quick info -->
					<div class="profile">
						<div class="profile_pic">
							<img src="../requirements/<?php echo "$pic";?>" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
							<span>Welcome,</span>
							<h2><?php echo $name; ?></h2>
						</div>
					</div>
					<!-- /menu profile quick info -->

					<br />

					<!-- sidebar menu -->
					<?php include('sidebar.php'); ?>
					<!-- /sidebar menu -->
				</div>
			</div>

			<!-- top navigation -->
			<div class="top_nav">
				<div class="nav_menu">
					<nav>
						<div class="nav toggle">
							<a id="menu_toggle"><i class="fa fa-bars"></i></a>
						</div>

						<ul class="nav navbar-nav navbar-right">
							<li class="">
								<a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
									<img src="../requirements/<?php echo "$pic";?>" alt=""><?php echo $name; ?>
									<span class=" fa fa-angle-down"></span>
								</a>
								<ul class="dropdown-menu dropdown-usermenu pull-right">
									
										<li><a href="javascript:;" data-toggle="modal" data-target="#change_password">Change Password</a></li>
										<li><a href="../index.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
									</ul>
								</li>
								<li role="presentation" class="dropdown">
									<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
										<i class="fa fa-envelope-o"></i>
										<span class="badge bg-green">
											<?php
											$userid = $_SESSION['id'];
											$sql = "SELECT * FROM message WHERE id = $userid AND message_status = 0 ";
											$query = $conn->query($sql);
											$count = $query->rowCount();
											echo $count;
											?>
										</span>
									</a>
									<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
										<li><h5>Message</h5></li><hr>
										<?php
										$userid = $_SESSION['id'];
										$sql = "SELECT * FROM message LEFT JOIN designee ON designee.designee_id = message.designee_id 
										WHERE id = $userid ";
										$query = $conn->prepare($sql);
										$query->execute();
										$count = $query->rowCount();
										$fetch = $query->fetchAll();

										foreach ($fetch as $key => $value) { ?>
										<li>
											<a href = "#message<?php echo $value['message_id'] ?>" data-toggle="modal">
												<span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
												<span>
													<span><?php echo $value['designee_name']; ?></span>
												</span>
												<span class="message">
													<?php echo $value['message_content']; ?>
													<span class="pull-right">
														<?php 
														if($value['message_status'] == 1){
															echo '<i class="fa fa-check-circle-o"></i>';
														}
														else{
															echo '<i class="fa fa-envelope"></i>';
														}
														?>
													</span>
												</span>
											</a>
										</li>

										<?php } ?>
									</ul>
								</li>
							</ul>
						</nav>
						<?php include '../message_modal.php';?>
					</div>
				</div>
				<!-- /top navigation -->

				<?php 
				$sql = "SELECT * FROM deadline ORDER BY id DESC LIMIT 1";
				$query = $conn->prepare($sql);
				$query->execute();
				$fetch = $query->fetch();

				$the_date = date('F d, Y', strtotime($fetch['d_date']));
				?>

				<!-- page content -->
				<div class="right_col" role="main">
					<div class="">
						<div class="page-title">
							<div class="title_left">
								<h3>Student </h3>
							</div>
						</div>
						<div class="clearfix"> <small class="pull-right">
							<?php 
							if ($fetch['status'] == 1){
								?>
								Deadline of submission of clearance is on <?php echo $the_date; ?>
								<?php 
							}
							?>
						</small></div>
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="x_panel">
								<div class="x_title">
									<h2>Departmental Clearance</h2>
									<div class="clearfix"></div>
								</div>

								<div class="x_content">
									<div class="row">
										<div class="col-md-12">
											<center>
												Federal Republic Of Nigeria<br />
												<strong>Federal University Of Technology Owerri</strong><br />
												
												
												<br />
												<strong>Departmental Clearance</strong>
												<br />
												<small>(Purpose: Service (NYSC), Further Studies, Scholarship)</small>
											</center>
										</div>
										<div class="row">
											<div class="col-md-3 pull-right">
												<center>______________
													<br />
													Date</center>
												</div>
											</div>
											<div class="row">
												<div class="col-md-3">
													<strong>The HOD</strong><br />
													
													Information Management Technology<br /><br />
													<u><?php echo $name; ?></u>:<br />
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<p>
														I have the honor to inform your good Office that I have satisfactoryily accounted for all money and property accountabilities and that all reports were complied with on dates shown below :
													</p>
													<table class="table table-bordered">
														<thead>
															<tr>
																<td>Forms/Reports</td>
																<td>Date Submitted</td>
																<td>Forms/Reports</td>
																<td>Date Submitted</td>
															</tr>
														</thead>
														<tbody>
															<tr>
																<td><strong>HOD:</strong> Clearance Form</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
																<td><strong>LAB. SCHOOL REQUIREMENTS:</strong></td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
															</tr>
															<tr>
																<td>Form 12</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
																<td><strong>Form 1</strong></td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
															</tr>
															<tr>
																<td> Statement of Assets & Liabilities</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
																<td><strong>Form 13</strong></td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
															</tr>
															<tr>
																<td><strong>REGISTRAR's:</strong> Class Cards</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
																<td>Form 8</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
															</tr>
															
															
															<tr>
																<td>Section Clearance</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
																<td>Departmental Clearance</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
															</tr>
															
															
															<tr>
																<td>School Form 19</td>
																<td><input type="text" name="vocational_year_graduated" data-inputmask="'mask': '99/99/9999'" class="form-control"></td>
																<td></td>
																<td></td>
															</tr>
														</tbody>
													</table>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12">
												<?php
												$userid = $_SESSION['id'];
												$sql = "SELECT * FROM clearance WHERE id = $userid ";
												$query = $conn->prepare($sql);
												$query->execute();
												$fetch = $query->fetchAll();

												foreach ($fetch as $key => $value) { ?>
												<form action="../update_clearance_until.php" method="post">
													<center>
														<label>Until
															<input type="text" class="col-md-1 pull-right" name="until" data-inputmask="'mask': '99/99/9999'" style="width: 70%;
															border-top: none; border-left: none; border-right:none; border-bottom: 1px solid; margin-right: 1px;" value="<?php echo $value['until']; ?>">
														</label>
														<label>, my mailing address will be
															<input type="text" class="col-md-1 pull-right" name="mailing_address" style="width: 51%;border-top: none;border-left: none;border-right: none;border-bottom: 1px solid;" value="<?php echo $value['mailing_address']; ?>">
														</label>
														<button type="submit" class="btn btn-primary btn-xs">Save</button>
													</center>
												</form>
											</div>
											<div class="col-md-3 pull-right">
												<div class="pull-right">
													<p>Very truly yours,</p>
													<u><?php echo $name; ?></u><br />
													<b>(Print name before signing)</b>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3 pull-right">
												<div class="pull-right">
													<u><?php echo $courseProgram ?></u><br />
													<b>(Course Program)</b>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12">
												<div class="row">
													<center><h2>Certification</h2>
														<p>WE HEREBY CERTIFY THAT <?php echo $name; ?> is cleared of all money, property and other accountabilities as of the date indicated.</p>
													</center>
												</div>
												
												<div class="row" style="border:1px solid;">
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_bursaryUnit_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Bursar</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_projectSupervisor_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Project Supervisor</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_classAdviser_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Class Adviser</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_departmentalAdmin_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Departmental Admin</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_studentAffairs_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Student Affairs</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_librarian_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Library</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_registrar_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Registrar</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_examsAndRecords_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Exams And Records</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
														<center>
															<?php 
															if ($value['is_dean_approval'] == 0){
																echo '';
															}else{
																echo '<i class="glyphicon glyphicon-ok"></i>';
															}
															?>
															<br />
															<p>________________________<br />
																<small>Dean</small>
															</p>
														</center>
													</div>
													<div class="col-md-4">
										
													<div class="col-md-4">
														<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
													
													
												</div>
												<div class="row">
													
													<center>
													<h4 style="margin-left:600px">APPROVED:</h4>
														<?php 
														if ($value['is_HOD_approval'] == 0){
															echo '';
														}else{
															echo '<i class="glyphicon glyphicon-ok"></i>';
														}
														?>
														<br />
														<p>________________________<br />
															<small>HOD</small>

															
														</p>
													</center>

												</div> 

												<?php include '../modal_designee.php'; ?>
												<?php include 'change_pass_modal.php';?>
												<?php } ?>
											</div>
										</div>
									</div>
								</div><!-- /x content -->
							</div><!-- /x panel -->
						</div>
					</div>
				</div>
				<!-- /page content -->

				<!-- footer content -->
				<footer>
					<div class="pull-right">
						By: IMT Group10
					</div>
					<div class="clearfix"></div>
				</footer>
				<!-- /footer content -->
			</div>
		</div>

		<!-- jQuery -->
		<script src="../vendors/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap -->
		<script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
		<!-- FastClick -->
		<script src="../vendors/fastclick/lib/fastclick.js"></script>
		<!-- NProgress -->
		<script src="../vendors/nprogress/nprogress.js"></script>
		<!-- jQuery custom content scroller -->
		<script src="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
		<!-- jquery.inputmask -->
		<script src="../vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
		<!-- Custom Theme Scripts -->
		<script src="../build/js/custom.min.js"></script>
		<script src="../build/js/md5.js"></script>
		<script>
			$(document).ready(function() {
				$(":input").inputmask();
			});
		</script>
		<!-- jquery.inputmask -->
		<script>
			$(document).ready(function() {
				$(":input").inputmask();

				var sess_id = '<?php echo $userid; ?>';

				$.ajax({
					type: 'POST',
					url: 'get_c.php?sess_id='+sess_id
				})
				.done(function(data){
						// console.log(data);
						var rw = JSON.parse(data);
						
						

						var c = arr.length;
						var msk = "'mask': '99/99/9999'";

			



							$('.add2').on('click', function(e){
								e.preventDefault();
							});
						});

$('form[name="change_p"]').on('submit', function(e){
	e.preventDefault();

	var sess_pass = '<?php echo $sess_pass; ?>';
	var sess_id = '<?php echo $session_id; ?>';

	var a = $('[name="old_pass"]').val();
	var b = $('[name="new_pass"]').val();
	var c = $('[name="conf_pass"]').val();

	if (md5(a) !== sess_pass){
		$('.edit_pass').text('Please enter your current password');
		$('[name="old_pass"]').val('').focus();
	}else{
		if (b === '' && c !== ''){
			$('.edit_pass').text('Please enter your new password');
		}else if (b !== '' && c === ''){
			$('.edit_pass').text('Please confirm your new password');
		}else if (b === '' && c === ''){
			$('.edit_pass').text('Please fill out the fields');
		}else if (b !== c){
			$('.edit_pass').text('Passwords do not match');
		}else{
			$.ajax({
				type: 'POST',
				url: 'edit_p.php',
				data: {
					session_id: sess_id,
					password: b
				}
			})
			.done(function(data){
				$('form[name="change_p"] input[type="password"]').val('');
				if (data == 1){
					$('.edit_pass').text('Password successfully updated');
				}else{
					$('.edit_pass').text('An error occured. Try again');
				}

				setTimeout(function(){
					location.reload();
				}, 1000 * 3);
			});	
		}
	}

});

});
</script>
<!-- /jquery.inputmask -->
</body>
</html>