<?php


include('../session_designee.php');
include('../connect.php');



?>
	
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Federal University Of Technology Owerri </title>


	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- jQuery custom content scroller -->
	<link href="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
	<!-- Switchery -->
	<link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
	<!-- Custom Theme Style -->
	<link href="../build/css/custom.min.css" rel="stylesheet">
	<!-- icon -->
	<link rel="icon" href="../images/green-chmsc-official-logo.png" >
</head>

<body class="nav-md">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col menu_fixed">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="#" class="site_title"><span>FUTO</span></a>
					</div>

					<div class="clearfix"></div>

					<!-- menu profile quick info -->
					<div class="profile">
						<div class="profile_pic">
						<img src="..\img\sample.png" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
							<span>Welcome,</span>
							<h2><?php echo $name_designee; ?></h2>
						</div>
					</div>
					<!-- /menu profile quick info -->

					<br />

					<!-- sidebar menu -->
					<?php include ('sidebar_designee.php'); ?>
					<!-- /sidebar menu -->
					<?php include ('change_pass_modal.php');?>
				</div>
			</div>

			
			<!-- top navigation -->
			<div class="top_nav">
			<div class="nav_menu">
				<nav>
					<div class="nav toggle">
						<a id="menu_toggle"><i class="fa fa-bars"></i></a>
					</div>

					<ul class="nav navbar-nav navbar-right">
						<li class="">
							<a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
							<img src="../images/img.jpg" alt="profile Image"><?php echo $name_designee; ?>
								<span class=" fa fa-angle-down"></span>
							</a>
							<ul class="dropdown-menu dropdown-usermenu pull-right">
								
									<li><a href="javascript:;" data-toggle="modal" data-target="#change_password">Change Password</a></li>
									<li><a href="../index.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
								
								</ul>
							</li>
							<li role="presentation" class="dropdown">
								<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
									<i class="fa fa-envelope-o"></i>
									<span class="badge bg-green">
										<?php
										$userid = $_SESSION['id'];
										$sql = "SELECT * FROM message WHERE id = $userid AND message_status = 0 ";
										$query = $conn->query($sql);
										$count = $query->rowCount();
										echo $count;
										?>
									</span>
								</a>
								<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
									<li><h5>Message</h5></li><hr>
									<?php
									$userid = $_SESSION['id'];
									$sql = "SELECT * FROM message LEFT JOIN designee ON designee.designee_id = message.designee_id 
									WHERE id = $userid ";
									$query = $conn->prepare($sql);
									$query->execute();
									$count = $query->rowCount();
									$fetch = $query->fetchAll();

									foreach ($fetch as $key => $value) { ?>
									<li>
										<a href = "#message<?php echo $value['message_id'] ?>" data-toggle="modal">
											<span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
											<span>
												<span><?php echo $value['designee_name']; ?></span>
											</span>
											<span class="message">
												<?php echo $value['message_content']; ?>
												<span class="pull-right">
													<?php 
													if($value['message_status'] == 1){
														echo '<i class="fa fa-check-circle-o"></i>';
													}
													else{
														echo '<i class="fa fa-envelope"></i>';
													}
													?>
												</span>
											</span>
										</a>
									</li>

									<?php } ?>
								</ul>
							</li>
						</ul>
					</nav>
					
					<?php include '../message_modal.php';?>
				</div>
			</div>
			<!-- /top navigation -->

	<!-- /top navigation -->

	<!-- page content -->
	<div class="right_col" role="main">
		<div class="">
			<div class="page-title">
				<div class="title_left">
					<h3><?php echo $name_designee; ?></h3>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="x_panel">
					<div class="x_title">
						<h2>List of Students</h2>
						<div class="clearfix"></div>
					</div>

					<div class="x_content">
						<table id="datatable-buttons" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th class="hidden">ID</th>
									<th>Reg No.</th>
									<th>Name</th>
									<th>Email</th>
									<th>Contact No.</th>
									<th>Department</th>
									<th>Course</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>


							<tbody>
								<?php
								//bursaryUnit Section
								$designee_id = $_SESSION['id']; 
								if ($designee_id == 1) { ?>
								<?php
								$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
								$query = $conn->prepare($sql);
								$query->execute();
								$fetch = $query->fetchAll();

								foreach ($fetch as $key => $value) { ?>
								<tr>
									<td class="hidden"><?php echo $value['id'] ?></td>
									<td><?php echo $value['stud_id'];?></td>
									<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
									<td><?php echo $value['email'] ?></td>
									<td><?php echo $value['contact_num']?></td>
									<td><?php echo $value['department']?></td>
									<td><?php echo $value['course']?></td>	
									<div class = "form-group">
										<td class = "center" style = "text-align:center; width: 15%;">
											<form action="../update_studentstatus.php" method="post">
												<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
												<?php 
												$user_id = $_SESSION['id'];
												if($user_id == 1){
													if ($value['is_bursaryUnit_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 2) {
													if ($value['is_projectSupervisor_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 3) {
													if ($value['is_classAdviser_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 4) {
													if ($value['is_departmentalAdmin_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 5) {
													if ($value['is_studentAffairs_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 6) {
													if ($value['is_librarian_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 7) {
													if ($value['is_registrar_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 8) {
													if ($value['is_examsAndRecords_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 9) {
													if ($value['is_dean_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												elseif ($user_id == 10) {
													if ($value['is_HOD_approval'] == 0){
														echo'
														<div class="form-group">
															<div class="col-md-12 col-sm-12 col-xs-12">
																<div class="">
																	<label>
																		<input type="submit" class="hidden" />
																		<input type="checkbox" class="js-switch" /> Unapproved
																	</label>
																</div>
															</div>
														</div>';
													}else{
														echo '<div class="form-group">
														<div class="col-md-9 col-sm-9 col-xs-12">
															<div class="">
																<label>
																	<input type="checkbox" class="js-switch" checked disabled/> Approved
																</label>
															</div>
														</div>
													</div>';}
												}
												
											
												?>
											</form>
										</td>
										<td>
											<form action="designee_view_status.php" method="post">
												<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
													<?php
													$user_id = $_SESSION['id'];
													if($user_id == 1){
														if ($value['is_bursaryUnit_approval'] == 0){
															echo'';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 2) {
														if ($value['is_projectSupervisor_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 3) {
														if ($value['is_classAdviser_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 4) {
														if ($value['is_departmentalAdmin_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 5) {
														if ($value['is_studentAffairs_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 6) {
														if ($value['is_librarian_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 7) {
														if ($value['is_registrar_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 8) {
														if ($value['is_examsAndRecords_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 9) {
														if ($value['is_dean_approval'] == 0){
															echo 'Unapproved';
														}else{
															echo 'disabled';
														}
													}
													elseif ($user_id == 10) {
														if ($value['is_HOD_approval'] == 0){
															echo 'Unchecked';
														}else{
															echo 'disabled';
														}
													}
											
										
													?>
													>
													<i class = "fa fa-envelope-o"></i>	
												</button>
												<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
												<button type="submit" class="btn btn-primary" <?php
												$user_id = $_SESSION['id'];
												if($user_id == 1){
													if ($value['is_bursaryUnit_approval'] == 0){
														echo'';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 2) {
													if ($value['is_projectSupervisor_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 3) {
													if ($value['is_classAdviser_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 4) {
													if ($value['is_departmentalAdmin_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 5) {
													if ($value['is_studentAffairs_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 6) {
													if ($value['is_librarian_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 7) {
													if ($value['is_registrar_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 8) {
													if ($value['is_examsAndrecords_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 9) {
													if ($value['is_dean_approval'] == 0){
														echo 'Unapproved';
													}else{
														echo 'disabled';
													}
												}
												elseif ($user_id == 10) {
													if ($value['is_HOD_approval'] == 0){
														echo 'Unchecked';
													}else{
														echo 'disabled';
													}
												}
										
											
										
												?>><i class = "fa fa-eye"></i>
												<span class="badge bg-green">
													<?php
													$a = $value['id'];
													$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
													$query = $conn->query($sql);
													$count = $query->rowCount();
													echo $count;
													?>
												</span>
											</button>
										</form>
										<?php include '../modal_sentmessage.php'; ?>
									</td>
								</div>
							</tr>														
							<?php } ?>
							<?php }





// projectSupervisor
							
$designee_id = $_SESSION['id']; 
if ($designee_id == 2) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

// classAdviser

$designee_id = $_SESSION['id']; 
if ($designee_id == 3) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//departmentalAdmin

$designee_id = $_SESSION['id']; 
if ($designee_id == 4) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//studentAffairs

$designee_id = $_SESSION['id']; 
if ($designee_id == 5) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//librarian

$designee_id = $_SESSION['id']; 
if ($designee_id == 6) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//registrar

$designee_id = $_SESSION['id']; 
if ($designee_id == 7) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//examsAndRecords

$designee_id = $_SESSION['id']; 
if ($designee_id == 8) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//dean

$designee_id = $_SESSION['id']; 
if ($designee_id == 9) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		<?php include '../modal_sentmessage.php'; ?>
	</td>
</div>
</tr>														
<?php } ?>
<?php }

//HOD

$designee_id = $_SESSION['id']; 
if ($designee_id == 10) { ?>
<?php
$sql = "SELECT * FROM student NATURAL JOIN clearance WHERE course_program = 'B.Tech'";
$query = $conn->prepare($sql);
$query->execute();
$fetch = $query->fetchAll();

foreach ($fetch as $key => $value) { ?>
<tr>
	<td class="hidden"><?php echo $value['id'] ?></td>
	<td><?php echo $value['stud_id'];?></td>
	<td><?php echo $value['stud_Fname'], '&nbsp;', $value['stud_Mname'], '&nbsp;', $value['stud_Lname']?></td>
	<td><?php echo $value['email'] ?></td>
	<td><?php echo $value['contact_num']?></td>
	<td><?php echo $value['department']?></td>
	<td><?php echo $value['course']?></td>	
	<div class = "form-group">
		<td class = "center" style = "text-align:center; width: 15%;">
			<form action="../update_studentstatus.php" method="post">
				<input value = "<?php echo $value['id'];?>" type="hidden" class="form-control" name= "id" placeholder="Reg No" >
				<?php 
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> &nbsp;Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndRecords_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo'
						<div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
								<div class="">
									<label>
										<input type="submit" class="hidden" />
										<input type="checkbox" class="js-switch" /> Unapproved
									</label>
								</div>
							</div>
						</div>';
					}else{
						echo '<div class="form-group">
						<div class="col-md-9 col-sm-9 col-xs-12">
							<div class="">
								<label>
									<input type="checkbox" class="js-switch" checked disabled/> Approved
								</label>
							</div>
						</div>
					</div>';}
				}
				
			
				?>
			</form>
		</td>
		<td>
			<form action="designee_view_status.php" method="post">
				<button type="button" href = "#edit<?php echo $value ['id']?>" data-toggle="modal" class = "btn btn-success btn-s" 
					<?php
					$user_id = $_SESSION['id'];
					if($user_id == 1){
						if ($value['is_bursaryUnit_approval'] == 0){
							echo'';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 2) {
						if ($value['is_projectSupervisor_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 3) {
						if ($value['is_classAdviser_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 4) {
						if ($value['is_departmentalAdmin_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 5) {
						if ($value['is_studentAffairs_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 6) {
						if ($value['is_librarian_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 7) {
						if ($value['is_registrar_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 8) {
						if ($value['is_examsAndRecords_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 9) {
						if ($value['is_dean_approval'] == 0){
							echo 'Unapproved';
						}else{
							echo 'disabled';
						}
					}
					elseif ($user_id == 10) {
						if ($value['is_HOD_approval'] == 0){
							echo 'Unchecked';
						}else{
							echo 'disabled';
						}
					}
			
		
					?>
					>
					<i class = "fa fa-envelope-o"></i>	
				</button>
				<input type="hidden" name="haydi" value="<?php echo $value ['id']?>">
				<button type="submit" class="btn btn-primary" <?php
				$user_id = $_SESSION['id'];
				if($user_id == 1){
					if ($value['is_bursaryUnit_approval'] == 0){
						echo'';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 2) {
					if ($value['is_projectSupervisor_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 3) {
					if ($value['is_classAdviser_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 4) {
					if ($value['is_departmentalAdmin_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 5) {
					if ($value['is_studentAffairs_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 6) {
					if ($value['is_librarian_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 7) {
					if ($value['is_registrar_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 8) {
					if ($value['is_examsAndrecords_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 9) {
					if ($value['is_dean_approval'] == 0){
						echo 'Unapproved';
					}else{
						echo 'disabled';
					}
				}
				elseif ($user_id == 10) {
					if ($value['is_HOD_approval'] == 0){
						echo 'Unchecked';
					}else{
						echo 'disabled';
					}
				}
		
			
		
				?>><i class = "fa fa-eye"></i>
				<span class="badge bg-green">
					<?php
					$a = $value['id'];
					$sql = "SELECT * FROM requirementstatus WHERE id = $a AND status = 0 AND designee_id = $user_id";
					$query = $conn->query($sql);
					$count = $query->rowCount();
					echo $count;
					?>
				</span>
			</button>
		</form>
		
		<?php include 'edit_password.php';?>
		<?php include '../modal_sentmessage.php'; ?>
		
	</td>
</div>
</tr>
													
<?php } ?>
<?php }

?>

</tbody>
</table>
</div><!-- /x content -->
</div><!-- /x panel -->
</div>
</div>
</div>
</div>
<!-- /page content -->

<!-- footer content -->
<footer>
	<div class="pull-right">
		By: IMT Group10
	</div>
	<div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src="../vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="../vendors/nprogress/nprogress.js"></script>
<!-- jQuery custom content scroller -->
<script src="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- Switchery -->
<script src="../vendors/switchery/dist/switchery.min.js"></script>
<script src="../build/js/md5.js"></script>


<!-- Custom Theme Scripts -->
<script src="../build/js/custom.min.js"></script>
<!-- Datatables -->
<script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="../vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
<script src="../vendors/jszip/dist/jszip.min.js"></script>
<script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
<!--/ Datatables -->

<script>
	$(document).ready(function() {
		var handleDataTableButtons = function() {
			if ($("#datatable-buttons").length) {
				$("#datatable-buttons").DataTable({
					dom: "Bfrtip",
					buttons: [
					{
						extend: "copy",
						className: "btn-sm"
					},
					{
						extend: "csv",
						className: "btn-sm"
					},
					{
						extend: "excel",
						className: "btn-sm"
					},
					{
						extend: "pdf",
						className: "btn-sm"
					},
					{
						extend: "print",
						className: "btn-sm"
					},
					],
					responsive: true
				});
			}
		};

		TableManageButtons = function() {
			"use strict";
			return {
				init: function() {
					handleDataTableButtons();
				}
			};
		}();

		$('#datatable').dataTable();

		$('#datatable-keytable').DataTable({
			keys: true
		});

		$('#datatable-responsive').DataTable();

		$('#datatable-scroller').DataTable({
			ajax: "js/datatables/json/scroller-demo.json",
			deferRender: true,
			scrollY: 380,
			scrollCollapse: true,
			scroller: true
		});

		$('#datatable-fixed-header').DataTable({
			fixedHeader: true
		});

		var $datatable = $('#datatable-checkbox');

		$datatable.dataTable({
			'order': [[ 1, 'asc' ]],
			'columnDefs': [
			{ orderable: false, targets: [0] }
			]
		});
		$datatable.on('draw.dt', function() {
			$('input').iCheck({
				checkboxClass: 'icheckbox_flat-green'
			});
		});

		TableManageButtons.init();
	});

	$('form[name="fchange_p"]').on('submit', function(e){
				e.preventDefault();

				var sess_pass = '<?php echo $a_sess_pass; ?>';
				var sess_id = '<?php echo $a_sess_id; ?>';

				var a = $('[name="old_pass"]').val();
				var b = $('[name="new_pass"]').val();
				var c = $('[name="conf_pass"]').val();

				if (md5(a) !== sess_pass){
					$('.edit_pass').text('Please enter your current password');
					$('[name="old_pass"]').val('').focus();
				}else{
					if (b === '' && c !== ''){
						$('.edit_pass').text('Please enter your new password');
					}else if (b !== '' && c === ''){
						$('.edit_pass').text('Please confirm your new password');
					}else if (b === '' && c === ''){
						$('.edit_pass').text('Please fill out the fields');
					}else if (b !== c){
						$('.edit_pass').text('Passwords do not match');
					}else{
						$.ajax({
							type: 'POST',
							url: 'edit_password.php',
							data: {
								session_id: sess_id,
								password: b
							}
						})
						.done(function(data){
							$('form[name="change_p"] input[type="password"]').val('');
							if (data == 1){
								$('.edit_pass').text('Password successfully updated');
							}else{
								$('.edit_pass').text('An error occured. Try again');
							}

							setTimeout(function(){
								location.reload();
							}, 1000 * 3);
						});	
					}
				}
			});
		});

</script>

<?php


if (isset($_POST['save']))
{
	$message= $_POST['message'];
	$designee_id = $_SESSION['id'];

	$sql = "INSERT INTO requirement(req_content,id,designee_id) VALUES(?,?)";
	$query = $conn->prepare($sql);
	$query->execute(array($message,$id));
	$count = $query->rowCount();

	if ($count > 0){
		echo "<script type='text/javascript'>alert('Requirement Added Succesfully');</script>";
		echo "<script>document.location='designee_addrequirements.php'</script>";
	}else{
		echo "<script type='text/javascript'>alert('Error creating alert!');</script>";
	}
}

?>

