<?php 
include('connect.php');
session_start();

if (!isset($_SESSION['id']) || ($_SESSION['id'] == '')){ ?>
	<script>
		window.location = 'index.php';
	</script>
	<?php
}

$session_id = $_SESSION['id'];

$sql = "SELECT * FROM student WHERE id = $session_id ";
$query = $conn->prepare($sql);
$query->execute(array($session_id));
$row = $query->fetch();

$name = $row['stud_Fname']. " " . $row['stud_Mname']. " " . $row['stud_Lname'];
$course = $row['course']; 
$pic = $row['stud_picture'];
$sess_pass = $row['password'];
$courseProgram = $row['course_program']
?>