<?php
include 'connect.php';

$id = $_POST['haydi'];

$query = $conn->prepare("UPDATE student SET status = ? WHERE id = $id");
	$query->execute(array(1));
	header('location:assets/admin1.php');

?>