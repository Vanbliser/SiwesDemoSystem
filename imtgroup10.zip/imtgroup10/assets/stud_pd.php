<?php
include('../session.php');
include('../connect.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Federal University Of Technology Owerri </title>

	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- CSS -->
	<link href="../assets/stylesheet.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- iCheck -->
	<link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	<!-- jQuery custom content scroller -->
	<link href="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
	<!-- Custom Theme Style -->
	<link href="../build/css/custom.min.css" rel="stylesheet">
	<!-- icon -->
	<link rel="icon" href="../images/green-chmsc-official-logo.png" >
</head>

<body class="nav-md">
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col menu_fixed">
				<div class="left_col scroll-view">
					<div class="navbar nav_title" style="border: 0;">
						<a href="#" class="site_title"><span>FUTO</span></a>
					</div>

					<div class="clearfix"></div>

					<!-- menu profile quick info -->
					<div class="profile">
						<div class="profile_pic">
							<img src="../requirements/<?php echo "$pic";?>" alt="..." class="img-circle profile_img">
						</div>
						<div class="profile_info">
							<span>Welcome,</span>
							<h2><?php echo $name; ?></h2>
						</div>
					</div>
					<!-- /menu profile quick info -->

					<br />

					<!-- sidebar menu -->
					<?php include('sidebar.php'); ?>
						<!-- /sidebar menu -->
					</div>
				</div>

				<!-- top navigation -->
				<div class="top_nav">
					<div class="nav_menu">
						<nav>
							<div class="nav toggle">
								<a id="menu_toggle"><i class="fa fa-bars"></i></a>
							</div>

							<ul class="nav navbar-nav navbar-right">
								<li class="">
									<a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										<img src="../requirements/<?php echo "$pic";?>" alt=""><?php echo $name; ?>
										<span class=" fa fa-angle-down"></span>
									</a>
									<ul class="dropdown-menu dropdown-usermenu pull-right">
										
										<li><a href="javascript:;" data-toggle="modal" data-target="#change_password">Change Password</a></li>
										<li><a href="../index.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
									</ul>
								</li>
								<li role="presentation" class="dropdown">
									<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
										<i class="fa fa-envelope-o"></i>
										<span class="badge bg-green">
											<?php
											$userid = $_SESSION['id'];
											$sql = "SELECT * FROM message WHERE id = $userid AND message_status = 0 ";
											$query = $conn->query($sql);
											$count = $query->rowCount();
											echo $count;
											?>
										</span>
									</a>
									<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
										<li><h5>Message</h5></li><hr>
										<?php
										$userid = $_SESSION['id'];
										$sql = "SELECT * FROM message LEFT JOIN designee ON designee.designee_id = message.designee_id 
										WHERE id = $userid ";
										$query = $conn->prepare($sql);
										$query->execute();
										$count = $query->rowCount();
										$fetch = $query->fetchAll();

										foreach ($fetch as $key => $value) { ?>
										<li>
											<a href = "#message<?php echo $value['message_id'] ?>" data-toggle="modal">
												<span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
												<span>
													<span><?php echo $value['designee_name']; ?></span>
												</span>
												<span class="message">
													<?php echo $value['message_content']; ?>
													<span class="pull-right">
														<?php 
														if($value['message_status'] == 1){
															echo '<i class="fa fa-check-circle-o"></i>';
														}
														else{
															echo '<i class="fa fa-envelope"></i>';
														}
														?>
													</span>
												</span>
											</a>
										</li>

										<?php } ?>
									</ul>
								</li>
							</ul>
						</nav>
						<?php include '../message_modal.php';?>
						<?php include 'change_pass_modal.php';?>
					</div>
				</div>
				<!-- /top navigation -->

				<!-- page content -->
				<div class="right_col" role="main">
					<div class="">
						<div class="page-title">
							<div class="title_left">
								<h3>Student</h3>
							</div>
						</div>
						<div class="clearfix"></div>
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="x_panel">
								<div class="x_title">
									<h2>Student Personal Data </h2>
									<div class="clearfix"></div>
								</div>
								<div class="row">
									
								</div>
								<div class="x_content col-md-12" >
									<form action="../update_stud_pd.php" method="post" class="form-horizontal form-label-left">
										<div class="container-fluid" style="border: 2px solid">
											<div class="col-md-4">
												Clearance Form  (Revised 2019)
											</div>
											<div class="col-md-4 pd_header">
												<h2><strong>PERSONAL DATA SHEET</strong></h2>
											</div>
											<div class="col-md-5 pull-right">
												<div class="form-group">
													<label class="control-label col-md-3 col-sm-3 col-xs-12 csc_label">1.Clearance ID No</label>
													<div class="col-md-9 col-sm-9 col-xs-12">
														<input type="number" class="form-control csc_no" name="cs_id_no" placeholder ="(To be Filled by senate)">
													</div>
												</div>
											</div>

											<div class="row">
												<div class="col-md-12">
													<ul class="nav nav-pills">
														<li class="active"><a data-toggle="pill" href="#personal_info">I.Personal Information</a></li>
														<li><a data-toggle="pill" href="#sponsor_information">II.Sponsor Information</a></li>
														<li><a data-toggle="pill" href="#program_details">III.Program Details</a></li>
													
												</div>
											</div>
											<br />
											<div class="tab-content">

												<!-- Personal info tab -->
												<div id="personal_info" class="tab-pane fade in active">
													<div class="row">
														<div class="col-md-12 category_header">
															<h4>I.Personal Information</h4>
														</div>
													</div>
													<div class="row">
														<?php
														$sql = "SELECT * FROM stud_pi
														NATURAL JOIN stud_pi_snk
														NATURAL JOIN stud_program_details WHERE id = $userid " ;
														
														 
														$query = $conn->prepare($sql);
														$query->execute();
														$fetch = $query->fetchAll();

														foreach ($fetch as $key => $value) { ?>
														<div class="col-md-2">
															<div class="col-md-12 bords form-group">
																<label class="control-label" for="surname">2. Surname</label>
																<br />
																<br />
																<label class="control-label">&nbsp;&nbsp;&nbsp;&nbsp;Firstname</label>
																<br />
																<br />
																<label class="control-label">&nbsp;&nbsp;&nbsp;&nbsp;Middlename</label>
															</div>
														</div>

														<div class="col-md-6">
															<div class="col-md-12 form-group">
																<input type="text" name="surname" class="form-control"  value = "<?php echo $value['surname'];?>">
															</div>
															<div class="col-md-6 form-group">
																<input type="text" name="firstname" class="form-control" value = "<?php echo $value['firstname'];?>">
															</div>
															<div class="col-md-6 form-group">
																<input type="text" name="middlename" class="form-control" value = "<?php echo $value['middlename'];?>">
															</div>
															<div class="col-md-6 form-group">
																<label class="control-label col-md-7">3. Name Extension (e.g. Mr., Miss.)
																</label>
																<div class="col-md-5">
																	<input type="text" name="name_extension" class="form-control col-md-7 col-xs-12 " value = "<?php echo $value['name_extension'];?>">
																</div>
															</div>
														</div>
													</div>
													<div class="row">
														<div class="col-md-5">
															<div class="row">
																<div class="col-md-8 form-group dob_label">
																	<label class="control-label">4. Date of Birth</label>
																</div>
																<div class="col-md-4 form-group">
																	<input type="text" name="dob" data-inputmask="'mask': '99/99/9999'" class="form-control dob_input" value = "<?php echo $value['dob'];?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group dob_label">
																	<label class="control-label">5. Place of Birth</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control dob_input" name="place_of_birth" value = "<?php echo $value['place_of_birth'];?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group dob_label">
																	<label class="control-label">6. State Of Origin</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control do_input" name="state_of_origin" value = "<?php echo $value['state_of_origin'];?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group dob_label">
																	<label class="control-label">7. Local Government</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control lga_input" name="LGA" value = "<?php echo $value['LGA'];?>">
																</div>
															</div>



															<div class="row">
																<div class="col-md-4 form-group dob_label">
																	<label class="control-label">8. Sex</label>
																</div>
																<div class="col-md-8 btn-group bords">
																	<label>Male:</label>
																	<input type="radio" class="flat" name="sex" id="genderM" value="M" 
																	<?php 
																	if ($value['sex'] == "M"){
																		echo "checked";
																	} 
																	?>> 
																	<label>Female:</label>
																	<input type="radio" class="flat" name="sex" id="genderF" value="F" 
																	<?php 
																	if ($value['sex'] == "F"){
																		echo "checked";
																	} 
																	?>
																	</div> 
																	</div>
																</div> 	
																<div class="row">
																<div class="col-md-6 form-group ht_label">
																	<label class="control-label">Home Town</label> <br>
																</div>
																<div class="col-md-6 form-group">
																	<input type="text" class="form-control ht_input" name="home_town" value = "<?php echo $value['home_town'];?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group pa_label">
																	<label class="control-label">10. Permanent Address</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control pa_input" name="permanent_address" value="<?php echo $value['permanent_address']; ?> ">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group dob_label">
																	<label class="control-label">11. Blood Group</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control dob_input" name="blood_group" value="<?php echo $value['blood_group']; ?> ">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group tel_label">
																	<label class="control-label">12. Tel:</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control tel_input" name="tel" value="<?php echo $value['tel']; ?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group genotype_label">
																	<label class="control-label">13. Genotype.</label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control genotype_input" name="genotype" value="<?php echo $value['genotype']; ?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group religion_label">
																	<label class="control-label"><small>14.Religion.</small></label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control religion_input" name="religion" value="<?php echo $value['religion']; ?>">
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group email_label">
																	<label class="control-label"><small>14.Email.</small></label>
																</div>
																<div class="col-md-8 form-group">
																	<input type="text" class="form-control email_input" name="email" value="<?php echo $value['email']; ?>">
																</div>
															</div>
															
																
															
																
															
															
															
															
												<!--/ Personal info tab -->

												<!-- Sponsor Information tab-->
												<div id="sponsor_information" class="tab-pane fade">
												<div class="row">
													<div class="col-md-12 category_header">
														<h4>II.Sponsor Information</h4>
														
													</div>
												</div>
												</div>
												<div class="row">
												<div class="col-md-4 form-group hayt">
													<label class="control-label">Sponsor's Name</label>
												
												</div>
												
												<div class="col-md-8">
													<div class="col-md-12 form-group">
														<input type="text" name="sponsor_name" class="form-control"  value="<?php echo $value['sponsor_name']; ?>">
													</div>
												</div>
											</div>
											</div>
											</div>
											</div>
											
															<div class="row">
															<div class="col-md-4 form-group hayt">
																<label class="control-label">Telephone No.</label>
															</div>
															
															<div class="col-md-8">
																<div class="col-md-12 form-group">
																	<input type="text" class="form-control" data-inputmask="'mask' : '(999) 999-9999'"  name="sponsor_num"  value="<?php echo $value['sponsor_num']; ?>">
																</div>
															</div>
														</div>
														</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Relationship</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="relationship" class="form-control"  value="<?php echo $value['relationship']; ?>">
																	</div>
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Next Of Kin</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="spon_next_of_kin" class="form-control"  value="<?php echo $value['spon_next_of_kin']; ?>">
																	</div>
																</div>
															</div>
															
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Next Of Kin Address</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="spon_next_of_kin_address" class="form-control"  value="<?php echo $value['spon_next_of_kin_address']; ?>">
																	</div>
																</div>
															</div>
                                                            
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Next Of Kin Mobile</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																	<input type="text" class="form-control" data-inputmask="'mask' : '(999) 999-9999'"  name="spon_next_of_kin_mobile"  value="<?php echo $value['spon_next_of_kin_mobile']; ?>">
																	</div>
																</div>
															</div>

															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Next Of Kin Email</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="spon_next_of_kin_email" class="form-control"  value="<?php echo $value['spon_next_of_kin_email']; ?>">
																	</div>
																</div>
															</div>
														
																<div id="program_details" class="tab-pane fade">
												<div class="row">
													<div class="col-md-12 category_header">
														<h4>III. Program Details</h4>
														
													</div>
												</div>
												</div>
												<div class="row">
												<div class="col-md-4 form-group hayt">
													<label class="control-label">Student Option</label>
												
												</div>
												
												<div class="col-md-8">
													<div class="col-md-12 form-group">
														<input type="text" name="option_std" class="form-control"  value="<?php echo $value['option_std']; ?>">
													</div>
												</div>
										
											
											
															<div class="row">
															<div class="col-md-4 form-group hayt">
																<label class="control-label">Student Type.</label>
															</div>
															
															<div class="col-md-8">
																<div class="col-md-12 form-group">
																	<input type="text" class="form-control"   name="student_type"  value="<?php echo $value['student_type']; ?>">
																</div>
															</div>
														</div>
														</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Programme</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="programme" class="form-control"  value="<?php echo $value['programme']; ?>">
																	</div>
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Jamb No</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="jamb_no" class="form-control"  value="<?php echo $value['jamb_no']; ?>">
																	</div>
																</div>
															</div>
															
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Mode Of Entry</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="mode_of_entry" class="form-control"  value="<?php echo $value['mode_of_entry']; ?>">
																	</div>
																</div>
															</div>
                                                            
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">student Mode</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																	<input type="text" class="form-control"   name="student_mode"  value="<?php echo $value['student_mode']; ?>">
																	</div>
																</div>
															</div>

															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Entry year</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="entry_year" data-inputmask="'mask': '9999'" class="form-control"  value="<?php echo $value['entry_year']; ?>">
																	</div>
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Year Of Graduation</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="year_of_graduation" data-inputmask="'mask': '9999'" class="form-control"  value="<?php echo $value['year_of_graduation']; ?>">
																	</div>
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Year Of Study</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="year_of_study" data-inputmask="'mask': '9999'" class="form-control"  value="<?php echo $value['year_of_study']; ?>">
																	</div>
																</div>
															</div>
															<div class="row">
																<div class="col-md-4 form-group hayt">
																	<label class="control-label">Entry Level</label>
																</div>
																<div class="col-md-8">
																	<div class="col-md-12 form-group">
																		<input type="text" name="entry_level" data-inputmask="'mask': '9999'" class="form-control"  value="<?php echo $value['entry_level']; ?>">
																	</div>
																</div>
															</div>
															</div>
																<!--/ End Of Sponsor Information tab-->

												<!-- Program Details tab-->
												
												
															<tr>
																				<td>
												<center>
																				<strong>	Declaration</strong><br /><br />
																					I Certify that the Information given in this form  is, to the best of my knowlegde and belief, correct and complete
																				</td>
																			</tr>
																			</center>
                                                            </div>
															</div>
															<table class="table table-bordered">
																			
																		</table>
																		
																	
																</tr>
																<tr>
																	<td>
																		<div class="col-md-12">
																			<button type="submit" class="btn btn-success pull-right">
																				Save</button>
																			</div>
																		</td>
																	</tr>
															 
									
														</div>	
																

											
													<!--/ Other Information -->
												</div>
												<?php } ?>
												<div class="col-md-12">
													<div class="pull-right">Clearance Form (Revised 2019)</div>
												</div>
											</div>
										</form>
									</div>	<!-- /x content -->
								</div>	<!-- /x panel -->
							</div>
						
					
					<!-- /page content -->

					<!-- footer content -->
					<footer>
						<div class="pull-right">
							By: IMT Group10
						</div>
						<div class="clearfix"></div>
					</footer>
					<!-- /footer content -->
				</div>
			</div>

			<!-- iCheck -->
			<script src="../vendors/iCheck/icheck.min.js"></script>
			<!-- jQuery -->
			<script src="../vendors/jquery/dist/jquery.min.js"></script>
			<!-- Bootstrap -->
			<script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
			<!-- FastClick -->
			<script src="../vendors/fastclick/lib/fastclick.js"></script>
			<!-- NProgress -->
			<script src="../vendors/nprogress/nprogress.js"></script>
			<!-- jQuery custom content scroller -->
			<script src="../vendors/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
			<!-- jquery.inputmask -->
			<script src="../vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>

			<!-- Custom Theme Scripts -->
			<script src="../build/js/custom.min.js"></script>
			<script src="../build/js/md5.js"></script>
			<!-- jquery.inputmask -->
			<script>
				$(document).ready(function() {
					$(":input").inputmask();

					var sess_id = '<?php echo $userid; ?>';

					$.ajax({
						type: 'POST',
						url: 'get_c.php?sess_id='+sess_id
					})
					.done(function(data){
			

							$('.add2').on('click', function(e){
								e.preventDefault();
							});
					});

					$('form[name="change_p"]').on('submit', function(e){
						e.preventDefault();

						var sess_pass = '<?php echo $sess_pass; ?>';
						var sess_id = '<?php echo $session_id; ?>';

						var a = $('[name="old_pass"]').val();
						var b = $('[name="new_pass"]').val();
						var c = $('[name="conf_pass"]').val();

						if (md5(a) !== sess_pass){
							$('.edit_pass').text('Please enter your current password');
							$('[name="old_pass"]').val('').focus();
						}else{
							if (b === '' && c !== ''){
								$('.edit_pass').text('Please enter your new password');
							}else if (b !== '' && c === ''){
								$('.edit_pass').text('Please confirm your new password');
							}else if (b === '' && c === ''){
								$('.edit_pass').text('Please fill out the fields');
							}else if (b !== c){
								$('.edit_pass').text('Passwords do not match');
							}else{
								$.ajax({
									type: 'POST',
									url: 'edit_p.php',
									data: {
										session_id: sess_id,
										password: b
									}
								})
								.done(function(data){
									$('form[name="change_p"] input[type="password"]').val('');
									if (data == 1){
										$('.edit_pass').text('Password successfully updated');
									}else{
										$('.edit_pass').text('An error occured. Try again');
									}

									setTimeout(function(){
										location.reload();
									}, 1000 * 3);
								});	
							}
						}

					});

				});
			</script>
			<!-- /jquery.inputmask -->
		</body>
		</html>