<?php 

$id = $_GET['sess_id'];

include '../connect.php';


$sql = "SELECT * FROM stud_pi
		NATURAL JOIN stud_pi_snk
		NATURAL JOIN stud_program_details
		
		 WHERE id = ? " ;
		$query = $conn->prepare($sql);
		$query->execute(array($id));
		$fetch = $query->fetchAll();

		

?>