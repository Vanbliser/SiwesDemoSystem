<?php
include 'connect.php';

if (isset($_POST['add'])){
	$studId = $_POST['studId'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$lastname = $_POST['lastname'];
	$contactnumber = $_POST['contact_num'];
	$email = $_POST['email'];
	$course = $_POST['course'];
	$department = $_POST['department'];
	
	$campus = $_POST['campus'];
	$courseProgram = $_POST['course_program'];

	$add = $conn->prepare("INSERT INTO student (stud_id, stud_Fname, stud_Mname, stud_Lname, contact_num, email, course, department,campus, course_program)
		VALUES (?,?,?,?,?,?,?,?,?,?) ");
	$add->execute(array($studId,$firstname,$middlename,$lastname,$contactnumber,$email,$course,$department,$campus,$courseProgram));
	
	$a = $conn->lastInsertId();
	$add1 = $conn->prepare("INSERT INTO clearance (id) VALUES (?)");
	$add1->execute(array($a));
	$add2 = $conn->prepare("INSERT INTO stud_pi (id) VALUES (?)");
	$add2->execute(array($a));
	$add2 = $conn->prepare("INSERT INTO stud_pi_snk (id) VALUES (?)");
	$add2->execute(array($a));
	$add2 = $conn->prepare("INSERT INTO stud_program_details (id) VALUES (?)");
	$add2->execute(array($a));
	
}
?>