<?php
include 'connect.php';

	$id = $_GET['id'];
	$sql = "DELETE FROM student WHERE id = '$id'";
	$delete = $conn->prepare($sql);
	$delete->execute();
	header('location:assets/admin.php');


?>