<?php
include 'session.php';
include 'connect.php';

$user_id = $_SESSION['id'];
$surname = $_POST['surname'];
$firstname = $_POST['firstname'];
$middlename = $_POST['middlename'];
$name_extension = $_POST['name_extension'];
$birthday = $_POST['dob'];
$place_of_birth = $_POST['place_of_birth'];
$state_of_origin = $_POST['state_of_origin'];
$LGA = $_POST['LGA'];
$sex = $_POST['sex'];
$home_town = $_POST['home_town'];
$permanent_address = $_POST['permanent_address'];
$blood_group = $_POST['blood_group'];
$tel = $_POST['tel'];
$genotype = $_POST['genotype'];
$religion = $_POST['religion'];
$Email = $_POST['email'];

//sponsor Details
$sponsor_name = $_POST['sponsor_name'];
$sponsor_num = $_POST['sponsor_num'];
$sponsor_email = $_POST['sponsor_email'];
$relationship = $_POST['relationship'];
$spon_next_of_kin = $_POST['spon_next_of_kin'];
$spon_next_of_kin_address = $_POST['spon_next_of_kin_address'];
$spon_next_of_kin_mobile = $_POST['spon_next_of_kin_mobile'];
$spon_next_of_kin_email = $_POST['spon_next_of_kin_email'];

// Program details


$option_std = $_POST['option_std'];
$student_type = $_POST['student_type'];
$programme = $_POST['programme'];
$jamb_no = $_POST['jamb_no'];
$mode_of_entry = $_POST['mode_of_entry'];
$student_mode = $_POST['student_mode'];
$entry_year= $_POST['entry_year'];
$year_of_graduation = $_POST['year_of_graduation'];
$year_of_study = $_POST['year_of_study'];
$entry_level = $_POST['entry_level'];



$query = $conn->prepare("UPDATE stud_pi SET surname = ?, firstname = ?, middlename = ?, name_extension = ?, dob = ?, place_of_birth = ?, state_of_origin = ?, LGA = ?, sex = ?, home_town = ?, permanent_address = ?, blood_group = ?, tel = ?, genotype = ?, religion = ?, email = ? WHERE id = $user_id"); 	
$query->execute(array($surname,$firstname,$middlename,$name_extension,$birthday,$place_of_birth,$state_of_origin,$LGA,$sex,$home_town,$permanent_address,$blood_group,$tel, $genotype,$religion, $Email));

$query2 = $conn->prepare("UPDATE stud_pi_snk SET sponsor_name = ?, sponsor_num = ?, sponsor_email = ?, relationship = ?, spon_next_of_kin = ?,  spon_next_of_kin_address = ?, spon_next_of_kin_mobile  = ?,  spon_next_of_kin_email = ?  WHERE id = $user_id");
$query2->execute(array($sponsor_name,$sponsor_num,$sponsor_email,$relationship,$spon_next_of_kin,$spon_next_of_kin_address,$spon_next_of_kin_mobile,$spon_next_of_kin_email));

$query3 = $conn->prepare("UPDATE stud_program_details SET  option_std = ?, student_type = ?, programme = ?, jamb_no = ?, mode_of_entry = ?, student_mode = ?, entry_year = ?, year_of_graduation = ?, year_of_study = ?, entry_level = ? WHERE id = $user_id");
$query3->execute(array($id,$option_std,$student_type,$programme,$jamb_no,$mode_of_entry,$entry_year,$year_of_graduation,$year_of_study,$entry_level));



header('location:assets/stud_pd.php');
?>